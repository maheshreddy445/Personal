package com.uaebank.notificationservice.management;

import com.uaebank.notificationservice.dto.TransactionEvent;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME)
    public void handleTransactionEvent(TransactionEvent event) {
        System.out.println("📩 Received Transaction Event: " + event);

        // Process notification logic here (e.g., send email/SMS)
    }
}

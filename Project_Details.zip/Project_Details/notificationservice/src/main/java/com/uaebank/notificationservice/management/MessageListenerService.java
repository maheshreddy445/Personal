package com.uaebank.notificationservice.management;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.amqp.rabbit.annotation.RabbitListener;

@Service
public class MessageListenerService {

    @Autowired
    private EmailService emailService;

    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME)
    public void receiveMessage(TransactionEvent event) {
        String content = "Transaction Notification:\n" +
                "Type: " + event.getTransactionType() + "\n" +
                "Amount: " + event.getAmount() + "\n" +
                "Description: " + event.getDescription();
        emailService.sendEmail(event.getEmail(), "Transaction Alert", content);
    }
}

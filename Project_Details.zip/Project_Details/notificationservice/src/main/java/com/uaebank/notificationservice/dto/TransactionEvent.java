package com.uaebank.notificationservice.dto;

import java.io.Serializable;

public class TransactionEvent implements Serializable {
    private Long transactionId; // This represents the transaction ID.
    private Long accountId;     // This is the account ID associated with the transaction.
    private Double amount;      // This is the amount involved in the transaction.
    private String description; // This is the description of the transaction.
    private String transactionType; // This could be "DEPOSIT", "WITHDRAWAL", etc.
    private String email;       // This is the email to which the notification will be sent.

    public TransactionEvent(Long transactionId, Long accountId, Double amount, String description, String transactionType, String email) {
        this.transactionId = transactionId;
        this.accountId = accountId;
        this.amount = amount;
        this.description = description;
        this.transactionType = transactionType;
        this.email = email;
    }

    // Getters and setters
    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}

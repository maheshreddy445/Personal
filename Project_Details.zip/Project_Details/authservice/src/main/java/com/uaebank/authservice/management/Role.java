package com.uaebank.authservice.management;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}

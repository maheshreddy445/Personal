package com.uaebank.account.management;

import org.springframework.data.jpa.repository.JpaRepository;

// ✅ Repository for Account Entity
public interface AccountRepository extends JpaRepository<Account, Long> {
}

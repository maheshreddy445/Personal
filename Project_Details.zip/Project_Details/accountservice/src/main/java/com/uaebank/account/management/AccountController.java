package com.uaebank.account.management;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/accounts")  // Correct base path for REST API
public class  AccountController {

    @Autowired
    private AccountService accountService;

    // POST /api/accounts - Create a new account
    @PostMapping
    public ResponseEntity<Account> createAccount(@RequestBody Account account) {
        Account createdAccount = accountService.createAccount(account);
        return ResponseEntity.ok(createdAccount);
    }

    // GET /api/accounts/{id} - Retrieve an account by its ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getAccountById(@PathVariable Long id) {
        Optional<Account> account = accountService.getAccountById(id);
        if (account.isPresent()) {
            return ResponseEntity.ok(account.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // GET /api/accounts/{id}/balance - Retrieve the balance of an account by its ID
    @GetMapping("/{id}/balance")
    public ResponseEntity<?> getAccountBalanceById(@PathVariable Long id) {
        Optional<Account> account = accountService.getAccountById(id);
        return account.map(a -> ResponseEntity.ok().body(new BalanceResponse(a.getBalance())))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // GET /api/accounts - Retrieve all accounts
    @GetMapping
    public ResponseEntity<List<Account>> getAllAccounts() {
        List<Account> accounts = accountService.getAllAccounts();
        return ResponseEntity.ok(accounts);
    }

    // PUT /api/accounts/{id} - Update an existing account
    @PutMapping("/{id}")
    public ResponseEntity<?> updateAccount(@PathVariable Long id, @RequestBody Account accountDetails) {
        return accountService.getAccountById(id)
                .map(existingAccount -> {
                    existingAccount.setUsername(accountDetails.getUsername());
                    existingAccount.setBalance(accountDetails.getBalance());
                    existingAccount.setEmail(accountDetails.getEmail());
                    existingAccount.setAccountType(accountDetails.getAccountType());
                    Account updatedAccount = accountService.updateAccount(existingAccount);
                    return ResponseEntity.ok(updatedAccount);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // DELETE /api/accounts/{id} - Delete an account
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAccount(@PathVariable Long id) {
        return accountService.getAccountById(id)
                .map(account -> {
                    accountService.deleteAccount(id);
                    return ResponseEntity.ok().<Void>build();
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Inner class to encapsulate the balance response
    private static class BalanceResponse {
        private double balance;

        public BalanceResponse(double balance) {
            this.balance = balance;
        }

        public double getBalance() {
            return balance;
        }

        public void setBalance(double balance) {
            this.balance = balance;
        }
    }
}

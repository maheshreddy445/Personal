package com.uaebank.account.management;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import jakarta.validation.constraints.NotNull;
import lombok.*;
@Entity
@Table(name = "accounts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long account_id;

    @NotNull(message = "Username cannot be null")
    @Column(name = "username", nullable = false, unique = true)
    private String username;

    @NotNull(message = "Userid cannot be null")
    @Column(name = "userid", nullable = false, unique = true)
    private String userid;



    @NotNull(message = "Email cannot be null")
    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @NotNull(message = "Accounttype cannot be null")
    @Column(name = "accounttype", nullable = false)
    private String accountType;

    @Column(name = "initialDeposit")
    private double initialDeposit;

    @Column(name = "balance")
    private double balance;

    @NotNull(message = "Aadhaar cannot be null")
    @Column(name = "aadhaar", nullable = false, unique = true)
    private String aadhaar;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now(); // Automatically set the creation time when the account is created
        }
    }
}

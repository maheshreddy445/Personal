package com.uaebank.transaction.management;

public enum TransactionType {
    DEPOSIT, WITHDRAWAL, TRANSFER
}

package com.uaebank.transaction.management;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionEventPublisher eventPublisher; // Inject the event publisher

    @Transactional
    public Transaction deposit(Long accountId, Double amount, String description) throws AccountNotFoundException {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new AccountNotFoundException("Account not found with ID: " + accountId));

        // Update the account balance
        account.setBalance(account.getBalance() + amount);
        accountRepository.save(account);

        // Record the transaction
        Transaction transaction = new Transaction();
        transaction.setAccountId(accountId);
        transaction.setAmount(amount);
        transaction.setDescription(description);
        transaction.setType(TransactionType.DEPOSIT);
        transaction.setTimestamp(LocalDateTime.now());  // Use LocalDateTime.now() here
        transaction = transactionRepository.save(transaction);

        // Publish the event
        TransactionEvent event = new TransactionEvent(transaction.getId(), accountId, amount, description, "DEPOSIT", account.getEmail());
        eventPublisher.publishTransactionEvent(event);

        return transaction;
    }

    @Transactional
    public Transaction withdraw(Long accountId, Double amount, String description) throws AccountNotFoundException, InsufficientFundsException {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new AccountNotFoundException("Account not found with ID: " + accountId));

        if (account.getBalance() < amount) {
            throw new InsufficientFundsException("Insufficient funds for withdrawal.");
        }

        // Update the account balance
        account.setBalance(account.getBalance() - amount);
        accountRepository.save(account);

        // Record the transaction
        Transaction transaction = new Transaction();
        transaction.setAccountId(accountId);
        transaction.setAmount(-amount); // Negative for withdrawal
        transaction.setDescription(description);
        transaction.setType(TransactionType.WITHDRAWAL);
        transaction.setTimestamp(LocalDateTime.now());  // Use LocalDateTime.now() here
        transaction = transactionRepository.save(transaction);

        // Publish the event
        TransactionEvent event = new TransactionEvent(transaction.getId(), accountId, -amount, description, "WITHDRAWAL", account.getEmail());
        eventPublisher.publishTransactionEvent(event);

        return transaction;
    }

    @Transactional
    public Transaction transfer(Long fromAccountId, Long toAccountId, Double amount, String description) throws AccountNotFoundException, InsufficientFundsException {
        Transaction withdrawal = this.withdraw(fromAccountId, amount, "Transfer to account " + toAccountId);
        Transaction deposit = this.deposit(toAccountId, amount, "Transfer from account " + fromAccountId);

        // Optionally, publish a transfer event or individual deposit/withdrawal events could be published
        return deposit;
    }
}

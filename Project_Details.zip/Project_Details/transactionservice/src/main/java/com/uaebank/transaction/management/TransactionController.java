package com.uaebank.transaction.management;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;


    @PostMapping("/deposit")
    public ResponseEntity<Transaction> deposit(@RequestBody TransactionRequest request) {
        Transaction transaction = transactionService.deposit(request.getAccountId(), request.getAmount(), request.getDescription());
        return ResponseEntity.ok(transaction);
    }
    @PostMapping("/withdrawal")
    public ResponseEntity<Transaction> withdrawal(@RequestBody TransactionRequest request) {

            Transaction transaction = transactionService.withdraw(request.getAccountId(), request.getAmount(), request.getDescription());
            return ResponseEntity.ok(transaction);

    }

    @PostMapping("/transfer")
    public ResponseEntity<Transaction> transfer(@RequestBody TransferRequest request) {

            Transaction transaction = transactionService.transfer(
                    request.getFromAccountId(),
                    request.getToAccountId(),
                    request.getAmount(),
                    request.getDescription()
            );
            return ResponseEntity.ok(transaction);

    }
}

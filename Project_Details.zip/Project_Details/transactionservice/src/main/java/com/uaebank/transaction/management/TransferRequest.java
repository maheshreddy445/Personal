package com.uaebank.transaction.management;

public class TransferRequest extends TransactionRequest {
    private Long toAccountId; // The account ID to which the transfer should be made
    private Long fromAccountId; // The account ID from which the transfer is made

    // Getter and setter for 'toAccountId'
    public Long getToAccountId() {
        return toAccountId;
    }

    public void setToAccountId(Long toAccountId) {
        this.toAccountId = toAccountId;
    }

    // Getter and setter for 'fromAccountId'
    public Long getFromAccountId() {
        return fromAccountId;
    }

    public void setFromAccountId(Long fromAccountId) {
        this.fromAccountId = fromAccountId;
    }
}

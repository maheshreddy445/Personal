package com.eduexcellence.feesms.model;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.eduexcellence.feesms.model.FeeDetails;

@Document(collection = "Student")


public class Student {
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private long rollNo;
//	@NotNull(message = "First Name must not be null")
	private String firstName;
//	@NotNull(message = "Last Name must not be null")
	private String lastName;
//	@NotNull(message = "Address must not be null")
	private String address;
//	@NotNull(message = "Phone No must not be null")
	private String phoneNo;
//	@NotNull(message = "Grade must not be null")
//	@Min(value = 1, message = "Grade must be between 1-12")
//	@Max(value = 12, message = "Grade must be between 1-12")
	private int grade;
//	@OneToOne(mappedBy = "student", cascade = CascadeType.ALL)

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getRollNo() {
		return rollNo;
	}

	public void setRollNo(long rollNo) {
		this.rollNo = rollNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

}

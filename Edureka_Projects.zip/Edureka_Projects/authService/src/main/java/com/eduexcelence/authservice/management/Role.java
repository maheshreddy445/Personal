package com.eduexcelence.authservice.management;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}

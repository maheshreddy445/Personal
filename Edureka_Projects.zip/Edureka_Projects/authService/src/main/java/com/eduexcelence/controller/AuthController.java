package com.eduexcelence.controller;

import com.eduexcelence.authservice.management.AuthService;
import com.eduexcelence.authservice.management.Role;
import com.eduexcelence.authservice.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired private AuthService authService;
    @Autowired private JwtUtil jwtUtil;

    // ✅ User Registration
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestParam String username,
                                      @RequestParam String password,
                                      @RequestParam Role role) {
        try {
        	
            String token = authService.registerUser(username, password, role);
            return ResponseEntity.ok().body("{\"message\": \"User registered successfully\", \"token\": \"" + token + "\"}");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("{\"error\": \"" + e.getMessage() + "\"}");
        }
    }

    // ✅ User Login (Returns JWT)
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestParam String username, @RequestParam String password) {
        try {
            String token = authService.loginUser(username, password);
            return ResponseEntity.ok().body("{\"token\": \"" + token + "\"}");
        } catch (Exception e) {
            return ResponseEntity.status(401).body("{\"error\": \"" + e.getMessage() + "\"}");
        }
    }

    // ✅ Validate JWT Token
    @GetMapping("/validateToken")
    public ResponseEntity<?> validateToken(@RequestHeader("Authorization") String token) {
        try {
            String jwt = token.replace("Bearer ", ""); // ✅ Remove "Bearer " prefix
            String username = jwtUtil.extractUsername(jwt);
            return ResponseEntity.ok().body("{\"username\": \"" + username + "\"}");
        } catch (Exception e) {
            return ResponseEntity.status(401).body("{\"error\": \"Invalid token\"}");
        }
    }
}

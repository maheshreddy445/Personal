package com.eduexcelence.authservice.security;

import jakarta.servlet.FilterChain;  // ✅ Change from javax to jakarta
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;
import java.io.IOException;

@Component
public class JwtFilter extends GenericFilterBean {

    private final String secretKey = "banking-secret";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // Continue the filter chain
        chain.doFilter(httpRequest, httpResponse);
    }
}

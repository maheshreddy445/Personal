package com.eduexcellence.studentms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EeduexcellenceStudentMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EeduexcellenceStudentMsApplication.class, args);
	}

}

package com.eduexcellence.studentms.service;

import java.util.List;
import java.util.Random;

import org.springframework.http.ResponseEntity;

import com.eduexcellence.studentms.model.Student;



public interface StudentService {

	public ResponseEntity<List<Student>> getAllStudent();

	public ResponseEntity<String> addNewStudent(Student student);

	public ResponseEntity<Student> getStudentById(int id);

	public ResponseEntity<String> updateStudentDetails(Student student);

	public ResponseEntity<String> deleteStudent(int id);

}

package com.eduexcellence.studentms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EeduexcellenceStudentMsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.eduexcellence.studentms.model;



import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Student")
public class Student {


	@Transient
	public static final String SEQUENCE_NAME = "users_sequence";
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int rollNo;
//	@NotNull(message = "First Name must not be null")
	private String firstName;
//	@NotNull(message = "Last Name must not be null")
	private String lastName;
//	@NotNull(message = "Address must not be null")
	private String address;
//	@NotNull(message = "Phone No must not be null")
	private String phoneNo;
//	@NotNull(message = "Grade must not be null")
//	@Min(value = 1, message = "Grade must be between 1-12")
//	@Max(value = 12, message = "Grade must be between 1-12")
	private int grade;
//	@OneToOne(mappedBy = "student", cascade = CascadeType.ALL)
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}

	public Student(int id, int rollNo, String firstName, String lastName, String address, String phoneNo, int grade) {
		this.id = id;
		this.rollNo = rollNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.phoneNo = phoneNo;
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "Student{" +
				"id=" + id +
				", rollNo=" + rollNo +
				", firstName='" + firstName + '\'' +
				", lastName='" + lastName + '\'' +
				", address='" + address + '\'' +
				", phoneNo='" + phoneNo + '\'' +
				", grade=" + grade +
				'}';
	}
}

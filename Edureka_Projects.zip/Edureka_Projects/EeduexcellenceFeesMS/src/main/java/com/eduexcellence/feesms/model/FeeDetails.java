package com.eduexcellence.feesms.model;

import org.springframework.data.annotation.Transient;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "FeeDetails")
public class FeeDetails {


	@Transient
	public static final String SEQUENCE_NAME = "users_sequence";
	@Id
	private long fid;
	private String startMonth;
	private String endMonth;
	private int currentYear;
	private String dateOfPayment;
	private double amount;
//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "student_id", referencedColumnName = "id")
	private Student student;
	public long getFid() {
		return fid;
	}
	public void setFid(long fid) {
		this.fid = fid;
	}
	public String getStartMonth() {
		return startMonth;
	}
	public void setStartMonth(String startMonth) {
		this.startMonth = startMonth;
	}
	public String getEndMonth() {
		return endMonth;
	}
	public void setEndMonth(String endMonth) {
		this.endMonth = endMonth;
	}
	public int getCurrentYear() {
		return currentYear;
	}
	public void setCurrentYear(int currentYear) {
		this.currentYear = currentYear;
	}
	public String getDateOfPayment() {
		return dateOfPayment;
	}
	public void setDateOfPayment(String dateOfPayment) {
		this.dateOfPayment = dateOfPayment;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	
}

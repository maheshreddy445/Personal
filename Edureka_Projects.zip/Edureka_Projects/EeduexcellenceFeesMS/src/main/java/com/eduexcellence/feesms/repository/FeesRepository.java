package com.eduexcellence.feesms.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.eduexcellence.feesms.model.FeeDetails;

@Repository
public interface FeesRepository extends MongoRepository<FeeDetails, Integer>{
	public List<FeeDetails> findByStudentId(int id);
}

package com.eduexcellence.feesms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EeduexcellenceFeesMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EeduexcellenceFeesMsApplication.class, args);
	}

}

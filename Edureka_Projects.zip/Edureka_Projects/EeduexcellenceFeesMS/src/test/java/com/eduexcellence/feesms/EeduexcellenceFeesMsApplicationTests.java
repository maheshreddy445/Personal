package com.eduexcellence.feesms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EeduexcellenceFeesMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
